class Strings {
  static String web_flutter = 'https://flutter.dev/';
  static String web_site = 'https://phichasignon-code.web.app/';
  static String yuotube = 'https://www.youtube.com/@pHicha_Sign_On';
  static String tiktok = 'https://www.tiktok.com/@phicha_sign_on';
  static String line =
      'https://line.me/R/ti/p/@741lqydx?from=page&accountId=741lqydx';
  static String facebook =
      'https://www.facebook.com/profile.php?id=100080212247642';
  static String cat = 'https://api.thedogapi.com/v1/images/search';
}
